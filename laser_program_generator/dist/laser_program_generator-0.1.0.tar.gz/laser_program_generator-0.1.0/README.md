# Laser Program Generator

Oh yeah, it's all coming together

```bash
laser-program-generator generate-program
```