# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['laser_program_generator']

package_data = \
{'': ['*']}

install_requires = \
['typer[all]>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['laser-program-generator = '
                     'laser_program_generator.main:app']}

setup_kwargs = {
    'name': 'laser-program-generator',
    'version': '0.1.0',
    'description': '',
    'long_description': "# Laser Program Generator\n\nOh yeah, it's all coming together\n\n```bash\nlaser-program-generator generate-program\n```",
    'author': 'Joshua Dyer',
    'author_email': 'dyerjo@mail.gvsu.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
